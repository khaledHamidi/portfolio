# Digital DATCOM Aerodynamic Examples

This folder contains a small, ready‑to‑run setup of **USAF Digital DATCOM** input and output files.

It is meant as a practical sandbox for:
- Testing aircraft aerodynamic models
- Comparing DATCOM results with MATLAB tools
- Learning / teaching basic stability and control concepts

## Contents

- `datcom.exe` – Digital DATCOM executable
- `*.dcm` – Aircraft geometry / configuration, input cases (e.g. `MiG17.dcm`)
- `*.out` – DATCOM output files, usable for plotting or MATLAB post‑processing

You can also check my website for more material about **Digital DATCOM**, **MATLAB**, and **aircraft aerodynamics**.

## License / Copyright

This entire repository is licensed under the GNU General Public License v3.0 (GPL-3.0).

You are free to use, copy, modify, and distribute this software, but any modified versions or derivative works must also be released under the GPL-3.0 license.

Copyright © 2025 Khaled HAMIDI
  
- **Website:** <https://khaledhamidi.com>  
- **Email:** <hamidi@engineer.com>  

